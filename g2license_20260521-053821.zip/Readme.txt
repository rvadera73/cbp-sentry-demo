- Senzing SDK uses a base64 string to specify license entitlement
    - This is contained in the g2.lic_base64 file
    - https://senzing.com/docs/tutorials/senzing_engine_config/

- Senzing EULA
    - https://senzing.com/end-user-license-agreement/

- Senzing Support
    - support@senzing.com
